import React from 'react'

const RightSec = () => {
  return (
    <div>
      {" "}
      <>
        <h1>RIGHT SIDE</h1>
        <h5>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius aliquid
          esse architecto labore sapiente libero cumque excepturi! Culpa
          distinctio, libero fugiat ad sit quos itaque deserunt nisi, voluptatum
          autem ullam vel. Odio voluptatum esse laudantium quasi quaerat
          repellendus labore. Dolores reprehenderit illum odio et sequi a facere
          porro nisi blanditiis explicabo! Autem fugit illo sit maxime odio,
          ducimus accusantium eius perferendis est sint modi vitae corporis
          corrupti deserunt, neque repudiandae debitis et dolor veniam minima
          eligendi cupiditate maiores? Numquam amet nesciunt deserunt cumque,
          tenetur facere dolorum maiores ad nam atque consequatur voluptates
          quos sed vero at facilis! Repudiandae natus tempora necessitatibus
          ullam velit perferendis, ipsa accusamus id magnam numquam iste at a,
          suscipit aut nisi ex error quasi quae reiciendis vitae? Dolore quod
          fugit labore unde, commodi repellendus consequatur impedit quas. Eum
          maxime dolorem nesciunt in magnam perspiciatis numquam alias, officia
          quidem consequatur mollitia voluptates voluptatum repellendus rem
          minima tempore necessitatibus. Possimus expedita totam enim? A
          sapiente cum culpa nobis quasi quos natus, asperiores consectetur eos
          enim sed. Itaque, illum voluptates quidem laudantium dolorum
          aspernatur tempora et perferendis omnis sed ullam impedit debitis,
          voluptate saepe voluptatibus nam sint necessitatibus deserunt. Minus,
          accusamus. Aspernatur consequuntur eveniet eos minus sapiente modi
          recusandae ipsa deserunt dolor veniam quisquam magni cum libero, iste
          consequatur consectetur autem accusantium ratione officia nesciunt.
          Commodi dolores quas repudiandae qui vitae asperiores pariatur
          necessitatibus obcaecati magnam voluptatem. Fugiat accusantium beatae
          odit blanditiis sapiente, illo nobis debitis! Sequi corporis
          similique, nulla quos nisi ex hic quod reiciendis nihil sapiente
          facere.
        </h5>
      </>
    </div>
  );
}

export default RightSec